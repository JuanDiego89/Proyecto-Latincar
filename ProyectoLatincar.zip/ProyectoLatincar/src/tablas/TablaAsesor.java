/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import modelo.Asesor;

/**
 *
 * @author Juan Diego
 */
public class TablaAsesor extends AbstractTableModel {
    private List<Asesor> lista = new ArrayList<Asesor>();

    public List<Asesor> getLista() {
        return lista;
    }

    public void setLista(List<Asesor> lista) {
        this.lista = lista;
    }
    @Override
    public int getRowCount() {
        return this.lista.size();
    }

    @Override
    public int getColumnCount() {
        return 7;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
        Asesor r = this.lista.get(fila);
        switch (columna) {
            case 0:
                return r.getCedula_asesor();
            case 1:
                return r.getApellido_asesor();
            case 2:
                return r.getNombre_asesor();
            case 3:
                return r.getTelefono_asesor();
            case 4  :
                return r.getEmail_asesor();
            case 5:
                return r.getCiudad_asesor();
            case 6:
                return r.getArea_asesor();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int columna) {
        switch (columna) {
            case 0:
                return "Cedula";
            case 1:
                return "Apellido";
            case 2:
                return "Nombre";
            case 3:
                return "Telefono";
            case 4: 
                return "Email";
            case 5:
                return "Ciudad";
            case 6:
                return "Direccion";
            default:
                return null;
        }

    }
    
}
