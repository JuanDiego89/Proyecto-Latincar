/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.List;
import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;
import modelo.Rol;

/**
 *
 * @author Juan Diego
 */
public class TablaRoles extends AbstractTableModel {

    private List<Rol> lista = new ArrayList<Rol>();

    public List<Rol> getLista() {
        return lista;
    }

    public void setLista(List<Rol> lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        return this.lista.size();
    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
        Rol r = this.lista.get(fila);
        switch (columna) {
            case 0:
                return r.getNombre_rol();
            case 1:
                return r.getDescripcion_rol();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int columna) {
        switch (columna) {
            case 0:
                return "Nombre Rol";
            case 1:
                return "Descripcion Rol";
            default:
                return null;
        }

    }

}
