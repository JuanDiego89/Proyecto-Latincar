/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.ArrayList;
import java.util.List;
import modelo.Vehiculo;

/**
 *
 * @author Juan Diego
 */
public class TablaVehiculo {

    private List<Vehiculo> lista = new ArrayList<Vehiculo>();

    public List<Vehiculo> getLista() {
        return lista;
    }

    public void setLista(List<Vehiculo> lista) {
        this.lista = lista;
    }

    public int getRowCount() {
        return this.lista.size();
    }

    public int getColumnCount() {
        return 24;
    }

    public Object getValueAt(int fila, int columna) {
        Vehiculo r = this.lista.get(fila);
        switch (columna) {
            case 0:
                return r.getPrecio_min();
            case 1:
                return r.getPrecio_max();
            case 2:
                return r.getKilometraje();
            case 3:
                return r.getPlaca_ac();
            case 4:
                return r.getPlaca_ant();
            case 5:
                return r.getAnio_matricula();
            case 6:
                return r.getNro_chasis();
            case 7:
                return r.getNro_motor();
            case 8:
                return r.getRamv();
            case 9:
                return r.getMarca();
            case 10:
                return r.getModelo();
            case 11:
                return r.getAnio_modelo();
            case 12:
                return r.getCilindraje();
            case 13:
                return r.getClas_vehiculo();
            case 14:
                return r.getTip_vehiculo();
            case 15:
                return r.getNro_pasajeros();
            case 16:
                return r.getToneladas();
            case 17:
                return r.getPais_origen();
            case 18:
                return r.getCombustible();
            case 19:
                return r.getCarroceria();
            case 20:
                return r.getTip_peso();
            case 21:
                return r.getColor1();
            case 22:
                return r.getColor2();
            case 23:
                return r.getRemarcado();
            case 24:
                return r.getClase_transporte();

            default:
                return null;
        }
    }

    public String getColumnName(int columna) {
        switch (columna) {
            case 0:
                return "Precio minimo";
            case 1:
                return "Precio maximo";
            case 2:
                return "Kilometraje";
            case 3:
                return "Placa actual";
            case 4:
                return "Placa anterior";
            case 5:
                return "Año matricula";
            case 6:
                return "Nro chasis";
                case 7:
                return "Nro_motor";
            case 8:
                return "Ramv";
            case 9:
                return "Marca";
            case 10:
                return "Modelo";
            case 11:
                return "Año modelo";
            case 12:
                return "Cilindraje";
            case 13:
                return "Clase de vehiculo";
            case 14:
                return "Tipo de vehiculo";
            case 15:
                return "Nro pasajeros";
            case 16:
                return "Toneladas";
            case 17:
                return "Pais de origen";
            case 18:
                return "Combustible";
            case 19:
                return "Carroceria";
            case 20:
                return "Tipo peso";
            case 21:
                return "Color 1";
            case 22:
                return "Color 2";
            case 23:
                return "Remarcado";
            case 24:
                return "Clase de transporte";
            default:
                return null;
        }

    }
}
