/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import modelo.Patio;

/**
 *
 * @author Juan Diego
 */
public class TablaPatio extends AbstractTableModel {
    private List<Patio> lista = new ArrayList<Patio>();

    public List<Patio> getLista() {
        return lista;
    }

    public void setLista(List<Patio> lista) {
        this.lista = lista;
    }
    @Override
    public int getRowCount() {
        return this.lista.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
        Patio r = this.lista.get(fila);
        switch (columna) {
            case 0:
                return r.getRuc_patio();
            case 1:
                return r.getNombre_patio();
            case 2:
                return r.getTelefono_patio();
            case 3:
                return r.getEmail_patio();
            case 4  :
                return r.getCiudad_patio();
            case 5:
                return r.getArea_patio();
            
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int columna) {
        switch (columna) {
            case 0:
                return "Ruc";
            case 1:
                return "Nombre";
            case 2:
                return "Telefono";
            case 3:
                return "Email";
            case 4: 
                return "Ciudad";
            case 5:
                return "Direccion";
            
            default:
                return null;
        }

    }
    
}
