/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import modelo.Usuario;

/**
 *
 * @author Juan Diego
 */
public class TablaUsuario extends AbstractTableModel {

    private List<Usuario> lista = new ArrayList<Usuario>();

    public List<Usuario> getLista() {
        return lista;
    }

    public void setLista(List<Usuario> lista) {
        this.lista = lista;
    }

    @Override
    public int getRowCount() {
        return this.lista.size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int fila, int columna) {
        Usuario r = this.lista.get(fila);
        switch (columna) {
            case 0:
                return r.getCedula_usuario();
            case 1:
                return r.getApellidos_usuario();
            case 2:
                return r.getNombre_usuario();
            case 3:
                return r.getObjeto_cuenta().getObjeto_rol().getNombre_rol();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int columna) {
        switch (columna) {
            case 0:
                return "Cedula Usuario";
            case 1:
                return "Apellidos Usuario";
            case 2:
                return "Nombres Usuario";
            case 3:
                return "Username";
            case 4:
                return "Rol del Usuario";
            default:
                return null;
        }

    }

}
