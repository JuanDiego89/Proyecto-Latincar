/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Juan Diego
 */
public class Vehiculo {
    private String precio_min;
    private String precio_max;
    private String kilometraje;
    private String placa_ac;
    private String placa_ant;
    private String anio_matricula;
    private String nro_chasis;
    private String nro_motor;
    private String ramv;
    private String marca;
    private String modelo;
    private String anio_modelo;
    private String cilindraje;
    private String clas_vehiculo;
    private String tip_vehiculo;
    private String nro_pasajeros;
    private String toneladas;
    private String pais_origen;
    private String combustible;
    private String carroceria;
    private String tip_peso;
    private String color1;
    private String color2;
    private String remarcado;
    private String clase_transporte;

    public String getPrecio_min() {
        return precio_min;
    }

    public void setPrecio_min(String precio_min) {
        this.precio_min = precio_min;
    }

    public String getPrecio_max() {
        return precio_max;
    }

    public void setPrecio_max(String precio_max) {
        this.precio_max = precio_max;
    }

    public String getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(String kilometraje) {
        this.kilometraje = kilometraje;
    }

    public String getPlaca_ac() {
        return placa_ac;
    }

    public void setPlaca_ac(String placa_ac) {
        this.placa_ac = placa_ac;
    }

    public String getPlaca_ant() {
        return placa_ant;
    }

    public void setPlaca_ant(String placa_ant) {
        this.placa_ant = placa_ant;
    }

    public String getAnio_matricula() {
        return anio_matricula;
    }

    public void setAnio_matricula(String anio_matricula) {
        this.anio_matricula = anio_matricula;
    }

    public String getNro_chasis() {
        return nro_chasis;
    }

    public void setNro_chasis(String nro_chasis) {
        this.nro_chasis = nro_chasis;
    }

    public String getNro_motor() {
        return nro_motor;
    }

    public void setNro_motor(String nro_motor) {
        this.nro_motor = nro_motor;
    }

    public String getRamv() {
        return ramv;
    }

    public void setRamv(String ramv) {
        this.ramv = ramv;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getAnio_modelo() {
        return anio_modelo;
    }

    public void setAnio_modelo(String anio_modelo) {
        this.anio_modelo = anio_modelo;
    }

    public String getCilindraje() {
        return cilindraje;
    }

    public void setCilindraje(String cilindraje) {
        this.cilindraje = cilindraje;
    }

    public String getClas_vehiculo() {
        return clas_vehiculo;
    }

    public void setClas_vehiculo(String clas_vehiculo) {
        this.clas_vehiculo = clas_vehiculo;
    }

    public String getTip_vehiculo() {
        return tip_vehiculo;
    }

    public void setTip_vehiculo(String tip_vehiculo) {
        this.tip_vehiculo = tip_vehiculo;
    }

    public String getNro_pasajeros() {
        return nro_pasajeros;
    }

    public void setNro_pasajeros(String nro_pasajeros) {
        this.nro_pasajeros = nro_pasajeros;
    }

    public String getToneladas() {
        return toneladas;
    }

    public void setToneladas(String toneladas) {
        this.toneladas = toneladas;
    }

    public String getPais_origen() {
        return pais_origen;
    }

    public void setPais_origen(String pais_origen) {
        this.pais_origen = pais_origen;
    }

    public String getCombustible() {
        return combustible;
    }

    public void setCombustible(String combustible) {
        this.combustible = combustible;
    }

    public String getCarroceria() {
        return carroceria;
    }

    public void setCarroceria(String carroceria) {
        this.carroceria = carroceria;
    }

    public String getTip_peso() {
        return tip_peso;
    }

    public void setTip_peso(String tip_peso) {
        this.tip_peso = tip_peso;
    }

    public String getColor1() {
        return color1;
    }

    public void setColor1(String color1) {
        this.color1 = color1;
    }

    public String getColor2() {
        return color2;
    }

    public void setColor2(String color2) {
        this.color2 = color2;
    }

    public String getRemarcado() {
        return remarcado;
    }

    public void setRemarcado(String remarcado) {
        this.remarcado = remarcado;
    }

    public String getClase_transporte() {
        return clase_transporte;
    }

    public void setClase_transporte(String clase_transporte) {
        this.clase_transporte = clase_transporte;
    }
    
    public String toString(){
        
        String retorno = "";
        retorno = retorno + this.precio_min + "\n" + this.precio_max+ 
                "\n" + this.kilometraje + "\n" + this.placa_ac + "\n" + this.placa_ant + "\n" + this.anio_matricula +
                "\n" + this.nro_chasis + this.nro_motor + "\n" + this.ramv + this.marca + "\n" + this.modelo +
                "\n" + this.anio_modelo + "\n" + this.cilindraje + this.clas_vehiculo + "\n" + this.tip_vehiculo + this.nro_pasajeros + 
                "\n" + this.toneladas + this.pais_origen + "\n" + this.combustible + "\n" + this.carroceria + "\n" + this.tip_peso + 
                "\n" + this.color1 + "\n" + this.color2 + "\n" + this.remarcado + "\n" + this.clase_transporte;
        return retorno;
    
    
}
}
