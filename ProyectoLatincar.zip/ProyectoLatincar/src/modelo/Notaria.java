/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Juan Diego
 */
@Entity
@Table (name="Notaria")
public class Notaria implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id_notaria;
    @Column (name= "ruc_notaria",length=50)
    private String ruc_notaria;
    @Column (name= "nombre_notaria",length=50)
    private String nombre_notaria;
    @Column (name= "registro_notaria",length=50)
    private String registro_notaria;
    @Column (name= "telefono_notaria",length=50)
    private String telefono_notaria;
    @Column (name= "email_notaria",length=50)
    private String email_notaria;
    @Column (name= "ciudad_notaria",length=50)
    private String ciudad_notaria;
    @Column (name= "area_notaria",length=50)
    private String area_notaria;

    public Long getId_notaria() {
        return id_notaria;
    }

    public void setId_notaria(Long id_notaria) {
        this.id_notaria = id_notaria;
    }

    public String getRuc_notaria() {
        return ruc_notaria;
    }

    public void setRuc_notaria(String ruc_notaria) {
        this.ruc_notaria = ruc_notaria;
    }

    public String getNombre_notaria() {
        return nombre_notaria;
    }

    public void setNombre_notaria(String nombre_notaria) {
        this.nombre_notaria = nombre_notaria;
    }

    public String getRegistro_notaria() {
        return registro_notaria;
    }

    public void setRegistro_notaria(String registro_notaria) {
        this.registro_notaria = registro_notaria;
    }

    public String getTelefono_notaria() {
        return telefono_notaria;
    }

    public void setTelefono_notaria(String telefono_notaria) {
        this.telefono_notaria = telefono_notaria;
    }

    public String getEmail_notaria() {
        return email_notaria;
    }

    public void setEmail_notaria(String email_notaria) {
        this.email_notaria = email_notaria;
    }

    public String getCiudad_notaria() {
        return ciudad_notaria;
    }

    public void setCiudad_notaria(String ciudad_notaria) {
        this.ciudad_notaria = ciudad_notaria;
    }

    public String getArea_notaria() {
        return area_notaria;
    }

    public void setArea_notaria(String area_notaria) {
        this.area_notaria = area_notaria;
    }

    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id_notaria != null ? id_notaria.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Notaria)) {
            return false;
        }
        Notaria other = (Notaria) object;
        if ((this.id_notaria == null && other.id_notaria != null) || (this.id_notaria != null && !this.id_notaria.equals(other.id_notaria))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.Notaria1[ id=" + id_notaria + " ]";
    }
    
}
