/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.List;

/**
 *
 * @author Juan Diego
 */
public class Notaria {
    private String ruc_notaria;
    private String nombre_notaria;
    private String registro_notaria;
    private String telefono_notaria;
    private String email_notaria;
    private String ciudad_notaria;
    private String area_notaria;
    private List<Notaria> lista_notarias;

    public String getRuc_notaria() {
        return ruc_notaria;
    }

    public void setRuc_notaria(String ruc_notaria) {
        this.ruc_notaria = ruc_notaria;
    }

    public String getNombre_notaria() {
        return nombre_notaria;
    }

    public void setNombre_notaria(String nombre_notaria) {
        this.nombre_notaria = nombre_notaria;
    }

    public String getRegistro_notaria() {
        return registro_notaria;
    }

    public void setRegistro_notaria(String registro_notaria) {
        this.registro_notaria = registro_notaria;
    }

    public String getTelefono_notaria() {
        return telefono_notaria;
    }

    public void setTelefono_notaria(String telefono_notaria) {
        this.telefono_notaria = telefono_notaria;
    }

    public String getEmail_notaria() {
        return email_notaria;
    }

    public void setEmail_notaria(String email_notaria) {
        this.email_notaria = email_notaria;
    }

    public String getCiudad_notaria() {
        return ciudad_notaria;
    }

    public void setCiudad_notaria(String ciudad_notaria) {
        this.ciudad_notaria = ciudad_notaria;
    }

    public String getArea_notaria() {
        return area_notaria;
    }

    public void setArea_notaria(String area_notaria) {
        this.area_notaria = area_notaria;
    }

    public List<Notaria> getLista_notarias() {
        return lista_notarias;
    }

    public void setLista_notarias(List<Notaria> lista_notarias) {
        this.lista_notarias = lista_notarias;
    }
    
    public String toString(){
        
        String retorno = "";
        retorno = retorno + this.ruc_notaria + "\n" + this.nombre_notaria+ "\n" + this.registro_notaria +
                "\n" + this.telefono_notaria + "\n" + this.email_notaria + "\n" + this.ciudad_notaria + "\n" + this.area_notaria;
        return retorno;
}
}
