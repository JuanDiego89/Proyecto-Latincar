/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.List;

/**
 *
 * @author Juan Diego
 */
public class Usuario {
    private String nombre_usuario;
    private String apellidos_usuario;
    private String cedula_usuario;
    private String dirrecion_usuario;
    private String telefono_usuario;
    private String email_usuario;
    private Cuenta objeto_cuenta;
   
            
    
   
    

    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public String getApellidos_usuario() {
        return apellidos_usuario;
    }

    public void setApellidos_usuario(String apellidos_usuario) {
        this.apellidos_usuario = apellidos_usuario;
    }

    public String getCedula_usuario() {
        return cedula_usuario;
    }

    public void setCedula_usuario(String cedula_usuario) {
        this.cedula_usuario = cedula_usuario;
    }

    public String getDirrecion_usuario() {
        return dirrecion_usuario;
    }

    public void setDirrecion_usuario(String dirrecion_usuario) {
        this.dirrecion_usuario = dirrecion_usuario;
    }

    public String getTelefono_usuario() {
        return telefono_usuario;
    }

    public void setTelefono_usuario(String telefono_usuario) {
        this.telefono_usuario = telefono_usuario;
    }

    public String getEmail_usuario() {
        return email_usuario;
    }

    public void setEmail_usuario(String email_usuario) {
        this.email_usuario = email_usuario;
    }

    public Cuenta getObjeto_cuenta() {
        return objeto_cuenta;
    }

    public void setObjeto_cuenta(Cuenta objeto_cuenta) {
        this.objeto_cuenta = objeto_cuenta;
    }

   

    
    public String toString(){
        
        String retorno = "";
        retorno = retorno + this.nombre_usuario + "\n" + this.apellidos_usuario+ 
                "\n" + this.cedula_usuario + "\n" + this.dirrecion_usuario + "\n" + this.email_usuario + "\n" + this.telefono_usuario ;
        return retorno;
    }
}
