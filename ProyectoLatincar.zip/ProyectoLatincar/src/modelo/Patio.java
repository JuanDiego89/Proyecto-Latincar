/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Juan Diego
 */
@Entity
@Table (name="Patio")

public class Patio implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id_patio;
    @Column (name= "ruc_patio",length=50)
    private String ruc_patio;
    @Column (name= "nombre_patio",length=50)
    private String nombre_patio;
    @Column (name= "registro_patio",length=50)
    private String telefono_patio;
    @Column (name= "email_notaria",length=50)
    private String email_patio;
    @Column (name= "ciudad_patio",length=50)
    private String ciudad_patio;
    @Column (name= "area_patio",length=50)
    private String area_patio;

    public Long getId_patio() {
        return id_patio;
    }

    public void setId_patio(Long id_patio) {
        this.id_patio = id_patio;
    }

    public String getRuc_patio() {
        return ruc_patio;
    }

    public void setRuc_patio(String ruc_patio) {
        this.ruc_patio = ruc_patio;
    }

    public String getNombre_patio() {
        return nombre_patio;
    }

    public void setNombre_patio(String nombre_patio) {
        this.nombre_patio = nombre_patio;
    }

    public String getTelefono_patio() {
        return telefono_patio;
    }

    public void setTelefono_patio(String telefono_patio) {
        this.telefono_patio = telefono_patio;
    }

    public String getEmail_patio() {
        return email_patio;
    }

    public void setEmail_patio(String email_patio) {
        this.email_patio = email_patio;
    }

    public String getCiudad_patio() {
        return ciudad_patio;
    }

    public void setCiudad_patio(String ciudad_patio) {
        this.ciudad_patio = ciudad_patio;
    }

    public String getArea_patio() {
        return area_patio;
    }

    public void setArea_patio(String area_patio) {
        this.area_patio = area_patio;
    }

    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id_patio != null ? id_patio.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Patio)) {
            return false;
        }
        Patio other = (Patio) object;
        if ((this.id_patio == null && other.id_patio != null) || (this.id_patio != null && !this.id_patio.equals(other.id_patio))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.Patio1[ id=" + id_patio + " ]";
    }
    
}
