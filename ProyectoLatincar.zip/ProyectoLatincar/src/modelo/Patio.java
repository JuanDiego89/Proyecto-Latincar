/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.List;

/**
 *
 * @author Juan Diego
 */
public class Patio {
     private String ruc_patio;
    private String nombre_patio;
   
    private String telefono_patio;
    private String email_patio;
    private String ciudad_patio;
    private String area_patio;
    private List <Patio> lista_patios;

    public String getRuc_patio() {
        return ruc_patio;
    }

    public void setRuc_patio(String ruc_patio) {
        this.ruc_patio = ruc_patio;
    }

    public String getNombre_patio() {
        return nombre_patio;
    }

    public void setNombre_patio(String nombre_patio) {
        this.nombre_patio = nombre_patio;
    }

    public String getTelefono_patio() {
        return telefono_patio;
    }

    public void setTelefono_patio(String telefono_patio) {
        this.telefono_patio = telefono_patio;
    }

    public String getEmail_patio() {
        return email_patio;
    }

    public void setEmail_patio(String email_patio) {
        this.email_patio = email_patio;
    }

    public String getCiudad_patio() {
        return ciudad_patio;
    }

    public void setCiudad_patio(String ciudad_patio) {
        this.ciudad_patio = ciudad_patio;
    }

    public String getArea_patio() {
        return area_patio;
    }

    public void setArea_patio(String area_patio) {
        this.area_patio = area_patio;
    }

    public List<Patio> getLista_patios() {
        return lista_patios;
    }

    public void setLista_patios(List<Patio> lista_patios) {
        this.lista_patios = lista_patios;
    }
    
    public String toString(){
        
        String retorno = "";
        retorno = retorno + this.ruc_patio + "\n" + this.nombre_patio+ 
                "\n" + this.telefono_patio + "\n" + this.email_patio + "\n" + this.ciudad_patio + "\n" + this.area_patio;
        return retorno;
    }
}
