/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Juan Diego
 */
@Entity
@Table (name="Asesor")
public class Asesor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id_asesor;

    @Column (name= "cedula_asesor",length=50)
    private String cedula_asesor;
    @Column (name= "nombre_asesor",length=50)
    private String nombre_asesor;
    @Column (name= "apellido_asesor",length=50)
    private String apellido_asesor;
    @Column (name= "telefono_asesor",length=50)
    private String telefono_asesor;
    @Column (name= "email_asesor",length=50)
    private String email_asesor;
    @Column (name= "ciudad_asesor",length=50)
    private String ciudad_asesor;
    @Column (name= "area_asesor",length=50)
    private String area_asesor;

    public Long getId_asesor() {
        return id_asesor;
    }

    public void setId_asesor(Long id_asesor) {
        this.id_asesor = id_asesor;
    }

    public String getCedula_asesor() {
        return cedula_asesor;
    }

    public void setCedula_asesor(String cedula_asesor) {
        this.cedula_asesor = cedula_asesor;
    }

    public String getNombre_asesor() {
        return nombre_asesor;
    }

    public void setNombre_asesor(String nombre_asesor) {
        this.nombre_asesor = nombre_asesor;
    }

    public String getApellido_asesor() {
        return apellido_asesor;
    }

    public void setApellido_asesor(String apellido_asesor) {
        this.apellido_asesor = apellido_asesor;
    }

    public String getTelefono_asesor() {
        return telefono_asesor;
    }

    public void setTelefono_asesor(String telefono_asesor) {
        this.telefono_asesor = telefono_asesor;
    }

    public String getEmail_asesor() {
        return email_asesor;
    }

    public void setEmail_asesor(String email_asesor) {
        this.email_asesor = email_asesor;
    }

    public String getCiudad_asesor() {
        return ciudad_asesor;
    }

    public void setCiudad_asesor(String ciudad_asesor) {
        this.ciudad_asesor = ciudad_asesor;
    }

    public String getArea_asesor() {
        return area_asesor;
    }

    public void setArea_asesor(String area_asesor) {
        this.area_asesor = area_asesor;
    }

    
    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id_asesor != null ? id_asesor.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Asesor)) {
            return false;
        }
        Asesor other = (Asesor) object;
        if ((this.id_asesor == null && other.id_asesor != null) || (this.id_asesor != null && !this.id_asesor.equals(other.id_asesor))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.Asesor1[ id=" + id_asesor + " ]";
    }
    
}
