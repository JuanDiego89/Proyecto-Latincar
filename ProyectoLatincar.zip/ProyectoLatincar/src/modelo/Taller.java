/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.List;

/**
 *
 * @author Juan Diego
 */
public class Taller {
    private String ruc_taller;
    private String nombre_taller;
   
    private String telefono_taller;
    private String email_taller;
    private String ciudad_taller;
    private String area_taller;
    private List <Taller> lista_talleres;

    public String getRuc_taller() {
        return ruc_taller;
    }

    public void setRuc_taller(String ruc_taller) {
        this.ruc_taller = ruc_taller;
    }

    public String getNombre_taller() {
        return nombre_taller;
    }

    public void setNombre_taller(String nombre_taller) {
        this.nombre_taller = nombre_taller;
    }

    public String getTelefono_taller() {
        return telefono_taller;
    }

    public void setTelefono_taller(String telefono_taller) {
        this.telefono_taller = telefono_taller;
    }

    public String getEmail_taller() {
        return email_taller;
    }

    public void setEmail_taller(String email_taller) {
        this.email_taller = email_taller;
    }

    public String getCiudad_taller() {
        return ciudad_taller;
    }

    public void setCiudad_taller(String ciudad_taller) {
        this.ciudad_taller = ciudad_taller;
    }

    public String getArea_taller() {
        return area_taller;
    }

    public void setArea_taller(String area_taller) {
        this.area_taller = area_taller;
    }

    public List<Taller> getLista_talleres() {
        return lista_talleres;
    }

    public void setLista_talleres(List<Taller> lista_talleres) {
        this.lista_talleres = lista_talleres;
    }
    
    public String toString(){
        
        String retorno = "";
        retorno = retorno + this.ruc_taller + "\n" + this.nombre_taller+ 
                "\n" + this.telefono_taller + "\n" + this.email_taller + "\n" + this.ciudad_taller + "\n" + this.area_taller;
        return retorno;
    }
}
