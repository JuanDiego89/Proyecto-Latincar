/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Juan Diego
 */
@Entity
@Table (name="Taller")
public class Taller implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id_taller;
    
    @Column (name= "ruc_taller",length=50)
    private String ruc_taller;
    @Column (name= "nombre_taller",length=50)
    private String nombre_taller;
    @Column (name= "telefono_taller",length=50)
    private String telefono_taller;
    @Column (name= "email_taller",length=50)
    private String email_taller;
    @Column (name= "ciudad_taller",length=50)
    private String ciudad_taller;
    @Column (name= "area_taller",length=50)
    private String area_taller;

    public Long getId_taller() {
        return id_taller;
    }

    public void setId_taller(Long id_taller) {
        this.id_taller = id_taller;
    }

    public String getRuc_taller() {
        return ruc_taller;
    }

    public void setRuc_taller(String ruc_taller) {
        this.ruc_taller = ruc_taller;
    }

    public String getNombre_taller() {
        return nombre_taller;
    }

    public void setNombre_taller(String nombre_taller) {
        this.nombre_taller = nombre_taller;
    }

    public String getTelefono_taller() {
        return telefono_taller;
    }

    public void setTelefono_taller(String telefono_taller) {
        this.telefono_taller = telefono_taller;
    }

    public String getEmail_taller() {
        return email_taller;
    }

    public void setEmail_taller(String email_taller) {
        this.email_taller = email_taller;
    }

    public String getCiudad_taller() {
        return ciudad_taller;
    }

    public void setCiudad_taller(String ciudad_taller) {
        this.ciudad_taller = ciudad_taller;
    }

    public String getArea_taller() {
        return area_taller;
    }

    public void setArea_taller(String area_taller) {
        this.area_taller = area_taller;
    }

    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id_taller != null ? id_taller.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Taller)) {
            return false;
        }
        Taller other = (Taller) object;
        if ((this.id_taller == null && other.id_taller != null) || (this.id_taller != null && !this.id_taller.equals(other.id_taller))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.Taller1[ id=" + id_taller + " ]";
    }
    
}
