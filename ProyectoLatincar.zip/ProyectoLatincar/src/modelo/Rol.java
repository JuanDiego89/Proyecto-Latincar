/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


import java.util.List;

/**
 *
 * @author Juan Diego
 */
public class Rol  {
    private String nombre_rol;
    private String descripcion_rol;
    private List <Rol> lista_roles;
    

    public List<Rol> getLista_roles() {
        return lista_roles;
    }

    public void setLista_roles(List<Rol> lista_roles) {
        this.lista_roles = lista_roles;
    }
    
    public String getNombre_rol() {
        return nombre_rol;
    }

    public void setNombre_rol(String nombre_rol) {
        this.nombre_rol = nombre_rol;
    }

    public String getDescripcion_rol() {
        return descripcion_rol;
    }

    public void setDescripcion_rol(String descripcion_rol) {
        this.descripcion_rol = descripcion_rol;
    }
    
    public String toString(){
        
        String retorno = "";
        retorno = retorno + this.nombre_rol;
        return retorno;
    }
    
}

          
