/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Servicio;

import controlador.Dao.TallerDao;
import java.util.List;
import modelo.Taller;

/**
 *
 * @author Bryan Nagua
 */
public class ServicioTaller {
     private TallerDao obj;
   public ServicioTaller(){
       this.obj=new TallerDao();
               
    }
    public Taller getObj() {
        return this.obj.getObj();
    }
     public boolean guardar() {
          return this.obj.guardar();
     }
     public boolean modificar() {
         return this.obj.modificar();
     }
        public void fijarInstancia(Taller obj) {
             this.obj.fijarInstancia(obj);
           
        }
        public void nuevaInstancia() {
              this.obj.nuevaInstancia();
        }
        public List<Taller> listar(){
            return this.obj.listar();
        }
        public Taller obtener(Long id){
            return this.obj.obtener(id);
        }   
}
