/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Servicio;

import controlador.Dao.AsesorDao;
import java.util.List;
import modelo.Asesor;

/**
 *
 * @author Bryan Nagua
 */
public class ServicioAsesor {
    private AsesorDao obj;
   public ServicioAsesor(){
       this.obj=new AsesorDao();
               
    }
    public Asesor getObj() {
        return this.obj.getObj();
    }
     public boolean guardar() {
          return this.obj.guardar();
     }
     public boolean modificar() {
         return this.obj.modificar();
     }
        public void fijarInstancia(Asesor obj) {
             this.obj.fijarInstancia(obj);
           
        }
        public void nuevaInstancia() {
              this.obj.nuevaInstancia();
        }
        public List<Asesor> listar(){
            return this.obj.listar();
        }
        public Asesor obtener(Long id){
            return this.obj.obtener(id);
        }   
}
