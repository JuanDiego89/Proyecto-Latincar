/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Servicio;

import controlador.Dao.CuentaDao;
import java.util.List;
import modelo.Cuenta;

/**
 *
 * @author Bryan Nagua
 */
public class ServicioCuenta {
    private CuentaDao obj;
    
    public ServicioCuenta(){
        this.obj = new CuentaDao();
    }
    
    public Cuenta getObj() {
        return this.obj.getObj();
    }
    
    public boolean guardar(){
        return this.obj.guardar();
    }
    
    public boolean modificar(){
         return this.obj.modificar();
     }
     
     public void fijarIistancia(Cuenta obj){
          this.fijarIistancia(obj);
     }
     
     public void nuevaInstancia(){
          this.nuevaInstancia();
     }
     
     public List<Cuenta> listar(){
         return this.obj.listar();
     }
     
     public Cuenta obtener(Long id){
         return this.obj.obtener(id);
     }
     
    public Cuenta iniciarSesion(String usuario,String clave){
        return this.obj.iniciarSesion(usuario, clave);
    }
}
