/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Servicio;

import controlador.Dao.RolDao;
import java.util.List;
import modelo.Rol;

/**
 *
 * @author Bryan Nagua
 */
public class ServicioRol {
    private RolDao obj;
    public ServicioRol(){
        this.obj = new RolDao();
    }
    
    public Rol getObj() {
        return this.obj.getObj();
    }
    
     public boolean guardar(){
         return this.obj.guardar();
     }
    
     public boolean modificar(){
         return this.obj.modificar();
     }
     
     public void fijarIistancia(Rol obj){
          this.fijarIistancia(obj);
     }
     
     public void nuevaInstancia(){
          this.nuevaInstancia();
     }
     
     public List<Rol> listar(){
         return this.obj.listar();
     }
     
     public Rol obtener(Long id){
         return this.obj.obtener(id);
     }
     
     public void crearRoles(){
         this.obj.crearRoles();
     }
     
     
     public Rol obtenerRolNombre(String nombre){
         return this.obj.obtenerRolNombre(nombre);
     }
}
