/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Servicio;

import controlador.Dao.ClienteDao;
import java.util.List;
import modelo.Cliente;

/**
 *
 * @author Bryan Nagua
 */
public class ServicioCliente {
    private ClienteDao obj;
   public ServicioCliente(){
       this.obj=new ClienteDao();
               
    }
    public Cliente getObj() {
        return this.obj.getObj();
    }
     public boolean guardar() {
          return this.obj.guardar();
     }
     public boolean modificar() {
         return this.obj.modificar();
     }
        public void fijarInstancia(Cliente obj) {
             this.obj.fijarInstancia(obj);
           
        }
        public void nuevaInstancia() {
              this.obj.nuevaInstancia();
        }
        public List<Cliente> listar(){
            return this.obj.listar();
        }
        public Cliente obtener(Long id){
            return this.obj.obtener(id);
        }   
}
