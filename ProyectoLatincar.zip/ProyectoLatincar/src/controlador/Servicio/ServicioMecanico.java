/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Servicio;

import controlador.Dao.MecanicoDao;
import java.util.List;
import modelo.Mecanico;

/**
 *
 * @author Bryan Nagua
 */
public class ServicioMecanico {
    private MecanicoDao obj;
   public ServicioMecanico(){
       this.obj=new MecanicoDao();
               
    }
    public Mecanico getObj() {
        return this.obj.getObj();
    }
     public boolean guardar() {
          return this.obj.guardar();
     }
     public boolean modificar() {
         return this.obj.modificar();
     }
        public void fijarInstancia(Mecanico obj) {
             this.obj.fijarInstancia(obj);
           
        }
        public void nuevaInstancia() {
              this.obj.nuevaInstancia();
        }
        public List<Mecanico> listar(){
            return this.obj.listar();
        }
        public Mecanico obtener(Long id){
            return this.obj.obtener(id);
        }   
}
