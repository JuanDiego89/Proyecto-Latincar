/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Servicio;

import controlador.Dao.PersonaDao;
import java.util.List;
import modelo.Persona;

/**
 *
 * @author Bryan Nagua
 */
public class ServicioPersona {
    private PersonaDao obj;
    
    public ServicioPersona(){
        this.obj = new PersonaDao();
    }
    
    public Persona getObj() {
        return this.obj.getObj();
    }
    
    public boolean guardar(){
        return this.obj.guardar();
    }
    
    public boolean modificar(){
         return this.obj.modificar();
     }
     
     public void fijarIistancia(Persona obj){
          this.obj.fijarIistancia(obj);
     }
     
     public void nuevaInstancia(){
          this.obj.nuevaInstancia();
     }
     
     public List<Persona> listar(){
         return this.obj.listar();
     }
     
     public Persona obtener(Long id){
         return this.obj.obtener(id);
     }
    public void crearAdministardor(){
        this.obj.crearAdministrador();
    }
    public Persona obtenerPersonaCedula(String cedula){
        return this.obj.obtenerPersonaCedula(cedula);
    }
}
