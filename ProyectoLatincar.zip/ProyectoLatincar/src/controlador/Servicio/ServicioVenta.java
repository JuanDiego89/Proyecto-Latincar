/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Servicio;

import controlador.Dao.VentaDao;
import java.util.List;
import modelo.Venta;

/**
 *
 * @author Bryan Nagua
 */
public class ServicioVenta {
    private VentaDao obj;
   public ServicioVenta(){
       this.obj=new VentaDao();
               
    }
    public Venta getObj() {
        return this.obj.getObj();
    }
     public boolean guardar() {
          return this.obj.guardar();
     }
     public boolean modificar() {
         return this.obj.modificar();
     }
        public void fijarInstancia(Venta obj) {
             this.obj.fijarInstancia(obj);
           
        }
        public void nuevaInstancia() {
              this.obj.nuevaInstancia();
        }
        public List<Venta> listar(){
            return this.obj.listar();
        }
        public Venta obtener(Long id){
            return this.obj.obtener(id);
        }   
}
