/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Dao;

import controlador.Conexion;
import modelo.Asesor;

/**
 *
 * @author Bryan Nagua
 */
public class AsesorDao extends AdaptadorDao<Asesor>{
    private Asesor obj;
    public AsesorDao(){
        super(new Conexion(), Asesor.class);
    }
    
    public Asesor getObj (){
        if (this.obj == null) {
            this.obj = new Asesor();
        }
        return obj;
    }
    
    public boolean guardar() {
        boolean ver = false;
        try {
            this.obj.setId_Asesor(this.gererarId());
            this.guardar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo guardar" + e);
        }
        return ver;
    }
    public boolean modificar() {
        boolean ver = false;
        try {
            this.modificar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo modificar" + e);
        }
        return ver;
    }
    public void fijarInstancia(Asesor obj) {
        this.obj = obj;
    }
    public void nuevaInstancia() {
        this.obj = null;
    } 
}
