/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Dao;

import controlador.Conexion;
import modelo.Cliente;

/**
 *
 * @author Bryan Nagua
 */
public class ClienteDao extends AdaptadorDao<Cliente>{
    private Cliente obj;
    public ClienteDao(){
        super(new Conexion(), Cliente.class);
    }
    
    public Cliente getObj (){
        if (this.obj == null) {
            this.obj = new Cliente();
        }
        return obj;
    }
    
    public boolean guardar() {
        boolean ver = false;
        try {
            this.obj.setId_cliente(this.gererarId());
            this.guardar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo guardar" + e);
        }
        return ver;
    }
    public boolean modificar() {
        boolean ver = false;
        try {
            this.modificar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo modificar" + e);
        }
        return ver;
    }
    public void fijarInstancia(Cliente obj) {
        this.obj = obj;
    }
    public void nuevaInstancia() {
        this.obj = null;
    } 
}
