/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Dao;

import controlador.Conexion;
import modelo.Cuenta;
import modelo.Persona;

/**
 *
 * @author Bryan Nagua
 */
public class CuentaDao extends AdaptadorDao<Cuenta>{
    private Cuenta obj;
    
    public CuentaDao(){
        super (new Conexion(), Cuenta.class);
        
    }
   
    public Cuenta getObj() {
        if (this.obj==null) 
            this.obj = new Cuenta();  
        return obj;
    }
    
    public boolean guardar(){
        boolean ver = false;
        try {
            this.obj.setId_cuenta(this.gererarId());
            this.guardar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo guardar"+e);
        }
        return ver;
    }
    
     public boolean modificar(){
        boolean ver = false;
        try {
            this.modificar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo guardar"+e);
        }
        return ver;
    }
    
     
     public void fijarIistancia(Cuenta obj){
         this.obj= obj;
     }
     
     public void nuevaInstancia(){
         this.obj=null;
     }
    public  void crearCuentaAdministrador(Persona p){
         if (this.listar().isEmpty()==true) {
             this.getObj().setClave("admin");
             this.getObj().setUsuario("admin");
             Persona paux = new Persona();
             paux.setId_persona(p.getId_persona());
             this.getObj().setPersona(paux);
             this.guardar();
         }
    }
    
    public Cuenta iniciarSesion(String usuario,String clave){
        Cuenta c=null;
        for (Cuenta aux: listar ()) {
            if (aux.getUsuario().equals(usuario)==true&&aux.getClave().equals(clave)==true) {
                c = aux;
                break;
            }
        }
        return c;
    }
}
