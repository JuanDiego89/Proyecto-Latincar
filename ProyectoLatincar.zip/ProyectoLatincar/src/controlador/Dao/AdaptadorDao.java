/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Dao;

import controlador.Conexion;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bryan Nagua
 */
public class AdaptadorDao<T> implements InterfazDao<T> {
    private Conexion conexion;
    private Class clazz;
    private String direccion;

    public AdaptadorDao(Conexion conexion, Class clazz) {
        this.conexion = conexion;
        this.clazz = clazz;
    }

    public String getDireccion() {
        this.direccion = this.conexion.getDireccionAbsoluta()+ clazz.getSimpleName()+".json";
        return direccion;
    }
    
    @Override
    public List<T> listar() {
        List<T> lista = new ArrayList<T>();
        try {
            Object obj = this.conexion.getXstream().fromXML(new FileInputStream(this.getDireccion()));
            List aux = (List) obj;
            lista = (List<T>) aux.get(0);//para trahajar con json
            //lista = (List<T>) aux;//para trabajar con xml
        } catch (Exception e) {
            System.out.println(e+" error en listar");
            this.conexion.Reiniciar();
        }
        return lista;
    }
    
    @Override
    public void guardar(T obj) throws Exception {
        List<T> lista = this.listar();
        lista.add(obj);
        this.conexion.getXstream().alias(clazz.getCanonicalName(), clazz.getClass());// alias coloca un nombre que se guarde 
        this.conexion.getXstream().toXML(lista, new FileOutputStream(this.getDireccion()));// el metodo toxml permite guardar un objeto en el archivo
    }
    
    @Override
    public T obtener(Long id) {// es programacion de alto nivel es cpmleja
        T obj = null;
        try {
            
            List<T> lista = this.listar();
            for (T t : lista) {
                Field aux = obtenerFieldId();
                Object value = aux.get(t);
                Long idAux = (Long) value;
                if (idAux.intValue() == id.intValue()) {
                    obj = t;
                    break;
                }
            }
        } catch (Exception e) {
        }
        return obj;
    }
    
    @Override
    public void modificar(T obj) throws Exception {// se debe tener el id 
        Field aux = obtenerFieldId();
        Long id = (Long) aux.get(obj);//mandamos el objeto y obtenemos
        T auxObj = obtener(id);
        if (auxObj != null) {
            List<T> lista = this.listar();
            lista.remove(id.intValue() - 1);
            lista.add(id.intValue() - 1, obj);
            this.conexion.getXstream().alias(clazz.getCanonicalName(), clazz.getClass());
            this.conexion.getXstream().toXML(lista, new FileOutputStream(this.getDireccion()));
        }
    }
    
    private Field obtenerFieldId() {// es privado este busca el id, este tiene que ser de tipo long
        Field aux = null;        
        Field[] fields = clazz.getDeclaredFields();
        try {
            
            for (Field f : fields) {
                f.setAccessible(true);                
                if (f.getType().getSimpleName().equals("Long") && f.getName().toLowerCase().contains("id")) {
                    aux = f;
                    break;
                }
            }
            if (aux == null) {
                Field[] fields2 = clazz.getSuperclass().getDeclaredFields();
                for (Field f : fields2) {
                    f.setAccessible(true);
                     System.out.println(f.getType().getSimpleName()+" ver herencia"+" "+f.getName());
                    if (f.getType().getSimpleName().equals("Long") && f.getName().toLowerCase().contains("id")) {
                        aux = f;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return aux;
    }
    
    @Override
    public Long gererarId() {
        Long id = new Long("1");
        if (this.listar().size() > 0) {
            id = new Long(this.listar().size() + 1);
        }
        return id;
    }
}
