/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Dao;

import controlador.Conexion;
import modelo.Vehiculo;

/**
 *
 * @author Bryan Nagua
 */
public class VehiculoDao extends AdaptadorDao<Vehiculo>{
    private Vehiculo obj;
    public VehiculoDao(){
        super(new Conexion(), Vehiculo.class);
    }
    
    public Vehiculo getObj (){
        if (this.obj == null) {
            this.obj = new Vehiculo();
        }
        return obj;
    }
    
    public boolean guardar() {
        boolean ver = false;
        try {
            this.obj.setId_Vehiculo(this.gererarId());
            this.guardar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo guardar" + e);
        }
        return ver;
    }
    public boolean modificar() {
        boolean ver = false;
        try {
            this.modificar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo modificar" + e);
        }
        return ver;
    }
    public void fijarInstancia(Vehiculo obj) {
        this.obj = obj;
    }
    public void nuevaInstancia() {
        this.obj = null;
    } 
}
