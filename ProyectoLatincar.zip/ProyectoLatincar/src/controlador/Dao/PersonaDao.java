/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Dao;

import controlador.Conexion;
import java.util.Date;
import modelo.Persona;

/**
 *
 * @author Bryan Nagua
 */
public class PersonaDao extends AdaptadorDao<Persona>{
    private Persona obj;
    
    public PersonaDao(){
        super (new Conexion(), Persona.class);
        
    }
   
    public Persona getObj() {
        if (this.obj==null) 
            this.obj = new Persona();  
        return obj;
    }
    
    public boolean guardar(){
        boolean ver = false;
        try {
            this.obj.setId_persona(this.gererarId());
            this.guardar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo guardar"+e);
        }
        return ver;
    }
    
     public boolean modificar(){
        boolean ver = false;
        try {
            this.modificar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo guardar"+e);
        }
        return ver;
    }
    
     
     public void fijarIistancia(Persona obj){
         this.obj= obj;
     }
     
     public void nuevaInstancia(){
         this.obj=null;
     }
     public  void crearAdministrador(){
         if (this.listar().isEmpty()==true) {
             this.getObj().setApellidos_per("admin");
             this.getObj().setNombres_per("admin");
             this.getObj().setCedula_per("2222222222");
             this.getObj().setDireccion_per("S/N");
             this.getObj().setEdad_per(20);
             this.getObj().setFechaNac_per(new Date());
             this.guardar();
             new CuentaDao().crearCuentaAdministrador(obj);
         }
     }
    
     public Persona obtenerPersonaCedula(String cedula){
         Persona p= null;
         for(Persona aux:this.listar()){
             if(aux.getCedula_per().equals(cedula)==true){
                 p=aux;
                 break;
             }
         }
         return p;
     }
}
