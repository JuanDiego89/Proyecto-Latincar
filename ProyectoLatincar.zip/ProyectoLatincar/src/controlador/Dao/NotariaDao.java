/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Dao;

import controlador.Conexion;
import modelo.Mecanico;
import modelo.Notaria;

/**
 *
 * @author Bryan Nagua
 */
public class NotariaDao extends AdaptadorDao<Notaria>{
    private Notaria obj;
    public NotariaDao(){
        super(new Conexion(), Notaria.class);
    }
    
    public Notaria getObj (){
        if (this.obj == null) {
            this.obj = new Notaria();
        }
        return obj;
    }
    
    public boolean guardar() {
        boolean ver = false;
        try {
            this.obj.setId_Notaria(this.gererarId());
            this.guardar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo guardar" + e);
        }
        return ver;
    }
    public boolean modificar() {
        boolean ver = false;
        try {
            this.modificar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo modificar" + e);
        }
        return ver;
    }
    public void fijarInstancia(Notaria obj) {
        this.obj = obj;
    }
    public void nuevaInstancia() {
        this.obj = null;
    } 
}
