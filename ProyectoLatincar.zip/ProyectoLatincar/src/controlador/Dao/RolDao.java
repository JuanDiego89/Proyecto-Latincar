/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador.Dao;

import controlador.Conexion;
import modelo.Rol;

/**
 *
 * @author Bryan Nagua
 */
public class RolDao extends AdaptadorDao<Rol>{
    private Rol obj;
    
    public RolDao() {
        super (new Conexion(), Rol.class);
    }

    public Rol getObj() {
        if (this.obj==null) 
            this.obj = new Rol();  
        return obj;
    }
    
    public boolean guardar(){
        boolean ver = false;
        try {
            this.obj.setId_rol(this.gererarId());
            this.guardar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo guardar"+e);
        }
        return ver;
    }
    
     public boolean modificar(){
        boolean ver = false;
        try {
            this.modificar(obj);
            ver = true;
        } catch (Exception e) {
            System.out.println("No se pudo guardar"+e);
        }
        return ver;
    }
    
     
     public void fijarIistancia(Rol obj){
         this.obj= obj;
     }
     
     public void nuevaInstancia(){
         this.obj=null;
     }
     
     public void crearRoles(){
         if (this.listar().isEmpty()==true) {
             this.nuevaInstancia();
             this.getObj().setNombre_rol("Administrador");
             this.guardar();
             this.nuevaInstancia();
             this.getObj().setNombre_rol("Medico");
             this.guardar();
             this.nuevaInstancia();
             this.getObj().setNombre_rol("Empleado");
             this.guardar();
             this.nuevaInstancia();
             this.getObj().setNombre_rol("Cliente");
             this.guardar();
             this.nuevaInstancia();
             
         }
     }
     
     public Rol obtenerRolNombre(String nombre){
         Rol r=null;
         for(Rol aux:this.listar()){
             if (aux.getNombre_rol().equalsIgnoreCase(nombre)) {
                 r=aux;
                 break;
             }
         }
         return r;
     }
}
